import { Userdisplay } from './userdisplay';

describe('Userdisplay', () => {
  it('should create an instance', () => {
    expect(new Userdisplay()).toBeTruthy();
  });
});
