export class Transaction{

    date:Date;
    id:number;
    action:String;
    amount:number;
}